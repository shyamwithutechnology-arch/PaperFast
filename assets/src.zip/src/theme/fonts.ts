 export const Fonts = {

    // instrument sans
    
    InstrumentSansRegular: 'InstrumentSans_SemiCondensed-Regular',
    InstrumentSansMedium : 'InstrumentSans-Medium',
    InstrumentSansSemiBold: 'InstrumentSans_SemiCondensed-SemiBold',
    InstrumentSansBold: 'InstrumentSans_SemiCondensed-Bold',
    InstrumentSansBlack: 'InstrumentSans_SemiCondensed-Black',
    InstrumentSansLight: 'InstrumentSans_SemiCondensed-Light',
    

    // inter 
    InterRegular:'Inter_28pt-Regular',
    InterMedium:'Inter_28pt-Medium',
    InterSemiBold:'Inter_28pt-SemiBold',
    InterBold:'Inter_28pt-Bold',
}