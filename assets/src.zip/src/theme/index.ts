export{Colors}from'./color';
export{Fonts}from'./fonts';