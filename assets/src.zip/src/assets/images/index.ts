export const Images = {
BgSplashImg: require('./BgSplashImg.png'),
bottomLayer: require('./bottomLayer.png'),
logo: require('./logo.png'),
topLayer:require('./topLayer.png'),
Rectangle45:require('./Rectangle45.png'),
Rectangle2:require('./Rectangle2.png'),
Rectangle3:require('./Rectangle3.png'),
Rectangle4:require('./Rectangle4.png'),
banner:require('./banner.png'),
banner1:require('./banner1.png'),
};